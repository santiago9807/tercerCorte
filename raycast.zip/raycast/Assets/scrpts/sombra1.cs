﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sombra1 : MonoBehaviour
{
    public Transform objSombra;

    // Update is called once per frame
    void Update()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.up, out hit))
        {
            Vector3 pos = hit.point;
            pos.y += 0.01f;
            objSombra.position = pos;
        }
    }
}
